const state={
  scrollHeight:0
};
const getters={

}
const mutations={
  setScrollHeight(state, val){
    state.scrollHeight = val;
  }
}
const actions={

}
export default{
    getters,
    mutations,
    actions,
    state
}
